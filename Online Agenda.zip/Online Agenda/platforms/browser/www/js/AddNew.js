(function () {
    "use strict";
    document.addEventListener("deviceready", onDeviceReady.bind(this), false);
    
	function onDeviceReady() {
		//Stopping the back key of the keyboard in Android
        document.addEventListener("backbutton", function () { }, false);
		
		//Back to home page when the user presses the back button
		document.getElementById("btnBack").addEventListener("click", function () { open("menu.html", "_self"); });
		
		//Save data when the user presses the save button
		document.getElementById("btnSave").addEventListener("click", Save);
		
		//Save data when the user presses the enter key of the keyboard
		document.addEventListener("keyup", function(e){if (e.keyCode==13) document.getElementById("btnSave").click();});
	}
	
	function Save(){
		var Homework = document.getElementById("Homework").value;
		var Grade = document.getElementById("Grade").value;
		var	thedate = document.getElementById("thedate").value;
	

		if (Homework.length == 0)
			document.getElementById("lblStatus").innerHTML = "Enter Homework";
		else if (Grade.length == 0)
			document.getElementById("lblStatus").innerHTML = "Enter Grade";
		else if (thedate.length == 0)
			document.getElementById("lblStatus").innerHTML = "Enter the date";
		
		else {
			document.getElementById("lblStatus").innerHTML = "Creating agenda, please wait...";
			
			var xmlhttp = new XMLHttpRequest();
			xmlhttp.onreadystatechange = function () {

				if (xmlhttp.readyState == 4 && xmlhttp.status == 200)
					if (xmlhttp.responseText) {
						
						alert("The agenda was successfully added. Press on show all to see all agendas");
						open("menu.html", "_self");
					}
					else {
            				alert("Agenda already exist");
            				document.getElementById("lblStatus").innerHTML = "Enter agenda";
          }
			};
			
			//xmlhttp.open("POST", "http://192.168.1.95/server/AddNew.php?Homework=" + Homework + "&Grade=" + Grade + "&thedate=" + thedate , true);
			//xmlhttp.send();
			
			
			
			xmlhttp.open("POST", "https://onlineagenda.000webhostapp.com/AddNew.php?Homework=" + Homework + "&Grade=" + Grade + "&thedate=" + thedate , true);
			xmlhttp.send();
			
			//xmlhttp.open("POST", "http://localhost/server/AddNew.php?Homework=" + Homework + "&Grade=" + Grade + "&thedate=" + thedate , true);
			//xmlhttp.send();
			
		}
		
		
	}
	
	
	
})();