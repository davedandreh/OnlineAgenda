(function () {
    "use strict";
    
    document.addEventListener('deviceready', onDeviceReady.bind(this), false);
    function onDeviceReady() {
		//Stopping the back key of the keyboard in Android
        document.addEventListener("backbutton", function () { }, false);
		
		//Back to home page when the user presses the back button
		document.getElementById("btnBack").addEventListener("click", function () { open("menu.html", "_self"); });
		
		document.getElementById("delete").addEventListener("click", todelete);
	
		
		document.getElementById("tblResults").innerHTML = "Loading results, please wait...";

        var xmlhttp = new XMLHttpRequest();
        xmlhttp.onreadystatechange = function () {
            if (xmlhttp.readyState == 4 && xmlhttp.status == 200) {
		
                var resp = JSON.parse(xmlhttp.responseText), RespLength = resp.length;
                if (!RespLength)
                    document.getElementById("tblResults").innerHTML = "No agendas found";
                else{
					
					var results = '<table border="1"><tr><th style="color:blue;font-size:125%">ID</th><th style="color:blue;font-size:125%">Homework</th><th style="color:blue;font-size:125%">Grade</th><th style="color:blue;font-size:125%">Date</th></tr>';
					for (var i = 0; i < RespLength; i++)
					
				
						results += "<tr><td style="+"font-size:125%"+" contenteditable style='color:black'>" + resp[i].id + "</td><td style="+"font-size:125%"+" contenteditable style='color:black'>" + resp[i].Homework + "</td><td style="+"font-size:125%"+" contenteditable style='color:black'>" + resp[i].Grade + "</td><td style="+"font-size:125%"+" contenteditable style='color:black'>" + resp[i].thedate + "</td>  </tr>";						
						
					
					
					document.getElementById("tblResults").innerHTML = results + '</table>';
					
				}   
            }
        };
		
	
		//xmlhttp.open("POST", "http://192.168.1.95/server/ShowAll.php", true);
        //xmlhttp.send();	
			
        xmlhttp.open("POST", "https://onlineagenda.000webhostapp.com/ShowAll.php", true);
        xmlhttp.send();
		
		
		//xmlhttp.open("POST", "http://localhost/server/ShowAll.php", true);
       // xmlhttp.send();
		
			
		}
			
	function todelete() {
			
			var id = document.getElementById("id").value;
			
			var xmlhttp1 = new XMLHttpRequest();
			xmlhttp1.onreadystatechange = function () {
				if (xmlhttp1.readyState == 4 && xmlhttp1.status == 200)
					if (xmlhttp1.responseText) {
						alert("Successfully deleted");
						open("ShowAll.html", "_self");
						
						
					}
					else {
            				alert("Not deleted");
            			
          }
			};
					
				
			//xmlhttp1.open("POST","http://192.168.1.95/server/Delete.php?id=" + id, true);
			//xmlhttp1.send();
			
			xmlhttp1.open("POST","https://onlineagenda.000webhostapp.com//Delete.php?id=" + id, true);
			xmlhttp1.send();
			
			//xmlhttp1.open("POST","http://localhost/server/Delete.php?id=" + id, true);
		//	xmlhttp1.send();				
			
		
    }
	
	
		

})();