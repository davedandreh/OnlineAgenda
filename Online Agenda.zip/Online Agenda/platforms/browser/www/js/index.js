﻿(function () {
    "use strict";
    document.addEventListener("deviceready", onDeviceReady.bind(this), false);

    function onDeviceReady() {
        document.addEventListener("backbutton", function () { navigator.app.exitApp();}, false);
	
        if (localStorage.getItem("AutoLogin") == "yes")			
            open("menu.html", "_self");
		else{
			document.getElementById("btnLogIn").addEventListener("click", function () { open("UserSignIn.html", "_self"); });
			document.getElementById("btnSignUp").addEventListener("click", function () { open("UserSignUp.html", "_self"); });
				
		}     
    };
})();

