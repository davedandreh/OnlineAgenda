﻿(function () {
    "use strict";
    document.addEventListener("deviceready", onDeviceReady.bind(this), false);

    function onDeviceReady() {
		//Stopping the back key of the keyboard in Android
		document.addEventListener("backbutton", function () { }, false);
		
		//Back to home page when the user presses the Signout button
		document.getElementById("btnSignOut").addEventListener("click", SignOut);
		
		var UserName = localStorage.getItem("UserName");
        document.getElementById("lblStatus").innerHTML = "Welcome " + UserName;
		
		
    document.getElementById("btnShow").addEventListener("click", function () { open("ShowAll.html", "_self"); });
	document.getElementById("btnAdd").addEventListener("click", function () { open("AddNew.html", "_self"); });
	
    }
	
		
	
	function SignOut(){
		//Clear localstorage variable UserName
		//If you want to clear all local storage variables use localStorage.clear();
		localStorage.setItem("UserName","");
		
		open("index.html", "_self");
	}
	
})();