(function () {
    "use strict";
    document.addEventListener("deviceready", onDeviceReady.bind(this), false);
    
	function onDeviceReady() {
		//Stopping the back key of the keyboard in Android
        document.addEventListener("backbutton", function () { }, false);
		
		//Back to home page when the user presses the back button
		document.getElementById("btnBack").addEventListener("click", function () { open("index.html", "_self"); });
		
		//Save data when the user presses the save button
		document.getElementById("btnSave").addEventListener("click", Save);
		
		//Save data when the user presses the enter key of the keyboard
		document.addEventListener("keyup", function(e){if (e.keyCode==13) document.getElementById("btnSave").click();});
	}
	
	function Save(){
		var FirstName = document.getElementById("txtFirstName").value;
		var LastName = document.getElementById("txtLastName").value;
		var UserName = document.getElementById("txtUserName").value;
		var Password = document.getElementById("txtPassword").value;
		var	PasswordConfirmed = document.getElementById("txtPasswordConfirmed").value;
		
		if (FirstName.length == 0)
			document.getElementById("lblStatus").innerHTML = "Enter your first name";
		else if (LastName.length == 0)
			document.getElementById("lblStatus").innerHTML = "Enter your last name";
		else if (UserName.length == 0)
			document.getElementById("lblStatus").innerHTML = "Enter your username";
		else if (Password.length < 6 || Password.length > 20)
			document.getElementById("lblStatus").innerHTML = "Your password must be 6 to 20 characters";
		else if(Password == '000000' || Password == '111111' || Password == '123456' || Password == '654321' || Password == '12345678' || Password == '87654321' || Password == 'ABCDEF' || Password == 'QWERTY' || Password == 'PASSWORD')
			document.getElementById("lblStatus").innerHTML = "This password is very weak, please choose another one";
		else if (PasswordConfirmed.length < 6 || PasswordConfirmed.length > 20)
			document.getElementById("lblStatus").innerHTML = "Your confirmed password must be 6 to 20 characters";
		else if (Password != PasswordConfirmed)
			document.getElementById("lblStatus").innerHTML = "Your password differs from the confirmed one";
		else {
			document.getElementById("lblStatus").innerHTML = "Creating user, please wait...";
			var xmlhttp = new XMLHttpRequest();
			xmlhttp.onreadystatechange = function () {
				if (xmlhttp.readyState == 4 && xmlhttp.status == 200)
					if (xmlhttp.responseText) {
						alert(UserName + " was successfully added. Press on Existing User to sign in");
						open("index.html", "_self");
					}
					else {
            				alert("UserName already exist");
            				document.getElementById("lblStatus").innerHTML = "Enter your details";
          }
			};
			
			//xmlhttp.open("POST", "http://192.168.1.95/server/SignUp.php?FirstName="+ FirstName + "&LastName=" + LastName + "&UserName=" + UserName + "&Password=" + Password, true);
			//xmlhttp.send();
			
			xmlhttp.open("POST", "https://onlineagenda.000webhostapp.com/SignUp.php?FirstName="+ FirstName + "&LastName=" + LastName + "&UserName=" + UserName + "&Password=" + Password, true);
			xmlhttp.send();
			
				//xmlhttp.open("POST", "http://localhost/server/SignUp.php?FirstName="+ FirstName + "&LastName=" + LastName + "&UserName=" + UserName + "&Password=" + Password, true);
			//xmlhttp.send();
		}
	}
	
})();