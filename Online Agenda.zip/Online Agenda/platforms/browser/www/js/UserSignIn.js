(function () {
    "use strict";
    document.addEventListener("deviceready", onDeviceReady.bind(this), false);
    
	function onDeviceReady() {
		//Stopping the back key of the keyboard in Android
        document.addEventListener("backbutton", function () { }, false);
		
		//Back to home page when the user presses the back button
		document.getElementById("btnBack").addEventListener("click", function () { open("index.html", "_self"); });
		
		//Login when the user presses the Login button
		document.getElementById("btnSave").addEventListener("click", Login);
		
		//Login when the user presses the enter key of the keyboard
		document.addEventListener("keyup", function(e){if (e.keyCode==13) document.getElementById("btnLogin").click();});
	}
		
	function Login() {
		var UserName = document.getElementById("txtUserName").value,Password = document.getElementById("txtPassword").value;
		if (UserName.length == 0)
			document.getElementById("lblStatus").innerHTML = "Enter your username";
		else if (Password.length == 0)
			document.getElementById("lblStatus").innerHTML = "Enter your password";
		else {
			document.getElementById("lblStatus").innerHTML = "Signing in, please wait...";
			var xmlhttp = new XMLHttpRequest();
			xmlhttp.onreadystatechange = function () {
				if (xmlhttp.readyState == 4 && xmlhttp.status == 200)
					if (xmlhttp.responseText){
						localStorage.setItem("UserName",UserName);
						open("menu.html", "_self");
					}
					else{
						document.getElementById("lblStatus").innerHTML = "Invalid UserName or Password";
						alert("Invalid UserName or Password");
					}
						
			};
			
			//xmlhttp.open("POST", "http://192.168.1.95/server/SignIn.php?UserName=" + UserName + "&Password=" + Password, true);
			//xmlhttp.send();
			
			xmlhttp.open("POST", "https://onlineagenda.000webhostapp.com/SignIn.php?UserName=" + UserName + "&Password=" + Password, true);
			xmlhttp.send();
			
			//xmlhttp.open("POST", "http://localhost/server/SignIn.php?UserName=" + UserName + "&Password=" + Password, true);
			//xmlhttp.send();
		}
	}
	
})();